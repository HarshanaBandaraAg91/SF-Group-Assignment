﻿using Microsoft.EntityFrameworkCore;
using SF_Group_Assignment_API.Models;

namespace SF_Group_Assignment_API
{
    public class AirshipDbContext : DbContext
    {
        public AirshipDbContext(DbContextOptions<AirshipDbContext> options) : base(options) { }

        public DbSet<Booking> Bookings { get; set; }
        public DbSet<Flight> Flights { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<UserProfile> UserProfiles { get; set; }
        public DbSet<FlightHistory> FlightHistories { get; set; }
        public DbSet<CheckoutDetails> CheckoutDetails { get; set; }
        public DbSet<Developer> Developers { get; set; }
        public DbSet<Contact> Contacts { get; set; }
    }
}
