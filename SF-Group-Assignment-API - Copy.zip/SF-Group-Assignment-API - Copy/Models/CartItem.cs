﻿namespace SF_Group_Assignment_API.Models
{
    public class CartItem
    {
        public required string Flight { get; set; }
        public required string From { get; set; }
        public required string To { get; set; }
        public required string Seat { get; set; }
    }
}
