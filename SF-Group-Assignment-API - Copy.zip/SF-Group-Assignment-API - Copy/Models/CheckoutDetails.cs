﻿namespace SF_Group_Assignment_API.Models
{
    public class CheckoutDetails
    {
        public required string PassengerName { get; set; }
        public DateTime FlightDate { get; set; }
        public required List<CartItem> Cart { get; set; }
        public required string PaymentMethod { get; set; }
        public required string CardNumber { get; set; }
        public required string ExpiryDate { get; set; }
        public required string CVV { get; set; }
    }
}
