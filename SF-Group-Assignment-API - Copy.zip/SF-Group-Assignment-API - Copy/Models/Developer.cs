﻿namespace SF_Group_Assignment_API.Models
{
    public class Developer
    {
        public int Id { get; set; }
        public required string Name { get; set; }
        public required string Role { get; set; }
        public required string Img { get; set; }
        public required string Description { get; set; }
        public required string Linkedin { get; set; }
        public required string Github { get; set; }
    }
}
