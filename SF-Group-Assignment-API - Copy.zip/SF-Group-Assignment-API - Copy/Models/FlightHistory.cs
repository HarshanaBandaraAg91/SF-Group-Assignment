﻿namespace SF_Group_Assignment_API.Models
{
    public class FlightHistory
    {
        public int FlightId { get; set; }
        public int UserId { get; set; }
        public required string FlightNumber { get; set; }
        public required string Destination { get; set; }
        public DateTime Date { get; set; }
        public required UserProfile UserProfile { get; set; }
    }
}
