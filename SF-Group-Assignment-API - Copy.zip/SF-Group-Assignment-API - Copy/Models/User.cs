﻿namespace SF_Group_Assignment_API.Models
{
    public class User
    {
        public int Id { get; set; }
        public required string Email { get; set; }
        public required string Password { get; set; }
    }

}
