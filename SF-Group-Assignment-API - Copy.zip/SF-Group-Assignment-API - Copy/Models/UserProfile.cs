﻿namespace SF_Group_Assignment_API.Models
{
    public class UserProfile
    {
        public int UserId { get; set; }
        public required string Email { get; set; }
        public required string ProfilePicture { get; set; }
        public required string VisaDetails { get; set; }
        public required ICollection<FlightHistory> FlightHistories { get; set; }
    }
}
