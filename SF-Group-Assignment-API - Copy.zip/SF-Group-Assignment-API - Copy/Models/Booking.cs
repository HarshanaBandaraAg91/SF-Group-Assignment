﻿namespace SF_Group_Assignment_API.Models
{
    public class Booking
    {
        // Models/Booking.cs
        
            public int Id { get; set; }
            public required string PassengerName { get; set; }
            public required string FlightNumber { get; set; }
            public required string SeatNumber { get; set; }
            public DateTime BookingDate { get; set; }
        

    }
}
