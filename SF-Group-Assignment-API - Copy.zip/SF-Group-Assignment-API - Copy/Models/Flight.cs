﻿namespace SF_Group_Assignment_API.Models
{
    public class Flight
    {
        // Models/Flight.cs
        
            public int Id { get; set; }
            public required string Airline { get; set; }
            public required string FlightNumber { get; set; }
            public DateTime Departure { get; set; }
            public DateTime Arrival { get; set; }
            public required string FromLocation { get; set; }
            public required string ToLocation { get; set; }
        

    }
}
