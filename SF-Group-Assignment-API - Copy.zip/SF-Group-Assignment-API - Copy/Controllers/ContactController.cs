﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SF_Group_Assignment_API.Models;

namespace SF_Group_Assignment_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContactController : ControllerBase
    {
        private readonly AirshipDbContext _context;

        public ContactController(AirshipDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        public async Task<IActionResult> SubmitContact([FromBody] Contact contact)
        {
            if (ModelState.IsValid)
            {
                _context.Contacts.Add(contact);
                await _context.SaveChangesAsync();
                return Ok(new { message = "Contact submitted successfully" });
            }

            return BadRequest(ModelState);
        }
    }
}
