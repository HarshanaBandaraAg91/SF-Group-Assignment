﻿using Microsoft.AspNetCore.Mvc;
using SF_Group_Assignment_API.Models;

namespace SF_Group_Assignment_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DevelopersController : ControllerBase
    {
        private readonly AirshipDbContext _context;

        public DevelopersController(AirshipDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public ActionResult<IEnumerable<Developer>> GetDevelopers()
        {
            return _context.Developers.ToList();
        }
    }
}
