﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SF_Group_Assignment_API.Models;

namespace SF_Group_Assignment_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserProfileController : ControllerBase
    {
        private readonly AirshipDbContext _context;

        public UserProfileController(AirshipDbContext context)
        {
            _context = context;
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<UserProfile>> GetUserProfile(int id)
        {
            var profile = await _context.UserProfiles.Include(p => p.FlightHistories)
                                                     .FirstOrDefaultAsync(p => p.UserId == id);
            if (profile == null)
            {
                return NotFound();
            }

            return Ok(profile);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateUserProfile(int id, [FromBody] UserProfile updatedProfile)
        {
            if (id != updatedProfile.UserId)
            {
                return BadRequest();
            }

            _context.Entry(updatedProfile).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpPost("upload-profile-picture")]
        public async Task<IActionResult> UploadProfilePicture(IFormFile profilePicture)
        {
            if (profilePicture == null || profilePicture.Length == 0)
            {
                return BadRequest("Invalid picture file.");
            }

            // Save profile picture logic here

            return Ok();
        }
    }
}
