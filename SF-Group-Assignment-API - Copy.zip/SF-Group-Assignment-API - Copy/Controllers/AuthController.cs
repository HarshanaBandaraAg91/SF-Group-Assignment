﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Org.BouncyCastle.Crypto.Generators;
using SF_Group_Assignment_API.Models;
using System;

namespace SF_Group_Assignment_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly AirshipDbContext _context;

        public AuthController(AirshipDbContext context)
        {
            _context = context;
        }

        [HttpPost("signup")]
        public async Task<IActionResult> Signup([FromBody] User user)
        {
            if (ModelState.IsValid)
            {
                // Check if the user already exists
                if (_context.Users.Any(u => u.Email == user.Email))
                {
                    return BadRequest(new { message = "User already exists" });
                }

                // Hash the password before saving (in production, use a stronger hash)
                user.Password = BCrypt.Net.BCrypt.HashPassword(user.Password);

                _context.Users.Add(user);
                await _context.SaveChangesAsync();
                return Ok(new { message = "User registered successfully" });
            }

            return BadRequest(ModelState);
        }
    }
}
