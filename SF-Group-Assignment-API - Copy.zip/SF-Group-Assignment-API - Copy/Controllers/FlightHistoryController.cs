﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SF_Group_Assignment_API.Models;

namespace SF_Group_Assignment_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FlightHistoryController : ControllerBase
    {
        private readonly AirshipDbContext _context;

        public FlightHistoryController(AirshipDbContext context)
        {
            _context = context;
        }

        [HttpGet("{userId}")]
        public async Task<ActionResult<IEnumerable<FlightHistory>>> GetFlightHistory(int userId)
        {
            var flightHistory = await _context.FlightHistories.Where(f => f.UserId == userId).ToListAsync();

            if (flightHistory == null)
            {
                return NotFound();
            }

            return Ok(flightHistory);
        }
    }
}
